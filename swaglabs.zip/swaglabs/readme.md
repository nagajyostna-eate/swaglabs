required software
Node js
VS Code
Playwright Vs Code Extension

install
npm install --save-dev prettier eslint eslint-config-prettier eslint-plugin-prettier
npm install --save-dev @playwright/test
npm install --save-dev typescript
npm install @faker-js/faker
npx playwright install-deps
npm install dotenv


to run the scripts
npx playwright test
